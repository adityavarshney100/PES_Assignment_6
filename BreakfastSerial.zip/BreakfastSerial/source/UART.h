/*
 * UART.h
 *
 *  Created on: Nov 9, 2020
 *      Author: aditya.vny95
 */

#ifndef UART_H_
#define UART_H_
#define UART_OVERSAMPLE_RATE (16)
#define SYS_CLOCK (24000000)					// 24 Mhz clock as requested
#define BAUD_RATE (38400)						// Baud rate set as 38400, as requested in the question
#define PARITY_BIT (0)							// since no parity is required
#define STOP_BIT (1)							// 1 since we need Stop bit as 2, for 1 stop bit set it as 0
#define DATA_SIZE (0)							// for 8 bit data mode set value 0, for 9 bit set v alue as 1

												// The UART code has been referenced from Dean's book, CH 8
void UART0_IRQHandler(void);					// This is the function that acts as the interrupt for user's keyboard input
void Init_UART0(void);							// Initialization code for the UART
int __sys_write(int iFileHandle, char *pcBuffer, int iLength);		// code that brings the printf/puts functionality in the code
int __sys_readc(void);												// code that brings the scanf/gets functionality in the code

#endif /* UART_H_ */
