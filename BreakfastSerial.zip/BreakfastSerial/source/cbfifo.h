/*
 * cbfifo.h
 *
 *  Created on: Nov 9, 2020
 *      Author: aditya.vny95
 */

#ifndef CBFIFO_H_
#define CBFIFO_H_
#define MAX_SIZE (256)							// Size of the CB FIFO

typedef struct {
	uint8_t data[MAX_SIZE];
	unsigned int head;
	unsigned int tail;
	unsigned int size;
} volatile Queue;

void Q_init(Queue *q);						// Initialize the CB FIFO
int Q_size(Queue *q);						// Returns the current size of the CB FIFO
int Q_full(Queue *q);						// Returns the full possible size of the CB FIFO
int Q_empty(Queue *q);						// Returns 0 as the size of the CB FIFO
int cbfifo_enqueue(Queue *q, uint8_t d);	// function to enqueue to the CB FIFO
uint8_t cbfifo_dequeue(Queue *q);			// function to dequeue from the CB FIFO


#endif /* CBFIFO_H_ */
