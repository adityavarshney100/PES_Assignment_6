/*
 * main.c - application entry point
 * 
 * Author Howdy Pierce, howdy.pierce@colorado.edu
 */
#include "sysclock.h"
#include <stdio.h>
#include "MKL25Z4.h"
#include <cbfifo.h>
#include <stdlib.h>
#include <UART.h>
#include <string.h>
#include <hexdump.h>

char str1[100];
char newString[10][10];
int ctr;
extern Queue TxQ, RxQ;

void process_command2(char *input)				// code referenced from https://www.w3resource.com/c-programming-exercises/string/c-string-exercise-31.php
{

	    int i,j;

	    j=0; ctr=0;
	    for(i=0;i<=(strlen(input));i++)
	    {
	        // if space or NULL found, assign NULL into newString[ctr]
	        if(input[i]==' '||input[i]=='\0')
	        {
	            newString[ctr][j]='\0';
	            ctr++;  //for next word
	            j=0;    //for next word, init index to 0
	        }
	        else
	        {
	            newString[ctr][j]=input[i];
	            j++;
	        }
	    }
}

int main(void)
{
	sysclock_init();

	// TODO: initialize the UART here
	Init_UART0();
	printf("Welcome to BreakfastSerial!\n\r");
	printf("Type 'Help' for help menu\n\r");
	// enter infinite loop

	while (1)
	{
		printf("\n\r? ");// blocking receive
	  	char v[20];
	  	int i=0;
	  	for(i=0;i<20;i++)						// taking the input from the user
	  	{
	  		scanf("%c",&v[i]);
	  		printf("%c",v[i]);					// printing it simultaneously
	  		if(v[i]==13)						// condition for Enter key press
	  		{
	  			break;
	  		}
	  	}
	  	v[i]='\0';								// adding a Null at the end of the array
	  	printf("\n\r");
	  	process_command2(v);					// sending the array to disect each word from the string

	  	if(strcasecmp(newString[0],"Author")==0)		// If the user types Author
	  	{
	  		printf("Aditya Varshney\r\n");
	  	}
	  	else if (strcasecmp(newString[0],"dump")==0 && ctr<3)	// If the user types Dump but does not type the full command
	  	{

	  		printf("Incomplete input '%s'\n\r",newString[0]);

	  	}
	  	else if (strcasecmp(newString[0],"dump")==0 && ctr==3)	// if the user types dump and types full command
	  	{
	  		printf("Printing HexDump %s  %s\n\r",newString[0],newString[1]);

	  		int num = (int)strtol(newString[1], NULL, 16);       // changes start address string to Hex
			if(strstr(newString[2],"x"))						// condition to check if the input for length is in Hex or decimal
			{
				int num1 = (int)strtol(newString[2], NULL, 16);	// changes length string to Hex
				hexdump(num,num1);
			}
			else
			 hexdump(num,atoi(newString[2]));					// changes length to Decimal
	  	}
	  	else if (strcasecmp(newString[0],"help")==0)			// condition for help menu
	  	{
	  		printf("'Author'- Shows the author for this code\n\r");
	  		printf("'Dump XX YY'- shows the Hex dump, showing values starting at memory location XX until XX+YY \n\r");
	  	}
	  	else
	  	{
	  		printf("Invalid input '%s' \n\r",newString[0]);		// condition for invalid inputs
	  	}
	}
	return 0 ;
}

