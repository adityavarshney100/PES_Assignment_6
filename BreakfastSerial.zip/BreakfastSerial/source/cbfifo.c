/*
 * cbfifo.c
 *
 *  Created on: Nov 9, 2020
 *      Author: aditya.vny95
 */

#include "MKL25Z4.h"
#include "cbfifo.h"

void Q_init(Queue *q)
{
    unsigned int i=0;
    for(i=0;i<MAX_SIZE;i++)
        q->data[i]=0;
    q->head=0;
    q->tail=0;
    q->size=0;
}

int Q_size(Queue *q)
{
    return q->size;
}

int Q_full(Queue *q)
{
	return q->size == MAX_SIZE;
}

int Q_empty(Queue *q)
{
	return q->size == 0;
}

int cbfifo_enqueue(Queue *q, uint8_t d)
{
    q->data[q->tail]=d;
    q->tail=((q->tail)+1)%MAX_SIZE;
    q->size++;
    return 0;
}

uint8_t cbfifo_dequeue(Queue *q)
{
    uint8_t i=0;
    i=q->data[q->head];
    q->data[q->head]=0;
    q->head=((q->head)+1)%MAX_SIZE;
    q->size--;
    return i;
}
