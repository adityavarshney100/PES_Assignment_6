/*
 * hexdump.c
 *
 *  Created on: Nov 10, 2020
 *      Author: aditya.vny95
 */


void hexdump(char* start,char* length)
{
	for(int i=0;i<length;i+=16)
	{
		printf("%08x: ",start);
			for(int j=0; j<16; j++)
			{
				printf(" %02x ", *start);
						start++;
			}
		printf("\n\r");
	}
}
