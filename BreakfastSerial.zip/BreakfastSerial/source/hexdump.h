/*
 * hexdump.h
 *
 *  Created on: Nov 10, 2020
 *      Author: aditya.vny95
 */

#ifndef HEXDUMP_H_
#define HEXDUMP_H_

void hexdump(char* start,char* length);				// Hexdump returns values of addresses requested from the user

#endif /* HEXDUMP_H_ */
